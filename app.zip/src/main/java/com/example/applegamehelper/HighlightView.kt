package com.example.applegamehelper

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

class HighlightView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {
    private val paint = Paint().apply {
        color = Color.parseColor("#99FF5722")
        style = Paint.Style.STROKE
        strokeWidth = 12.0f
        isAntiAlias = true
    }
    private var combinations = listOf<List<Pair<Int, Rect>>>()
    fun setCombinations(newCombinations: List<List<Pair<Int, Rect>>>) {
        this.combinations = newCombinations
        postInvalidate()
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        combinations.forEach { c -> c.forEach { (_, r) -> canvas.drawRect(r, paint) } }
    }
}