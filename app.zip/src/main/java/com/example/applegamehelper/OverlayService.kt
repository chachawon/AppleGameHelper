package com.example.applegamehelper

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*

class OverlayService : Service() {
    companion object {
        private const val TAG = "OverlayService"
        const val ACTION_START = "ACTION_START"; const val ACTION_STOP = "ACTION_STOP"
        const val EXTRA_RESULT_CODE = "EXTRA_RESULT_CODE"; const val EXTRA_DATA = "EXTRA_DATA"
        private const val NOTIFICATION_CHANNEL_ID = "OverlayServiceChannel"; private const val NOTIFICATION_ID = 1
        private const val ANALYSIS_INTERVAL_MS = 500L
    }
    private lateinit var wm: WindowManager; private lateinit var mpm: MediaProjectionManager
    private var highlightView: HighlightView? = null; private var mp: MediaProjection? = null
    private var vd: VirtualDisplay? = null; private var ir: ImageReader? = null
    private val density by lazy { Resources.getSystem().displayMetrics.densityDpi }
    private val width by lazy { Resources.getSystem().displayMetrics.widthPixels }
    private val height by lazy { Resources.getSystem().displayMetrics.heightPixels }
    private val job = SupervisorJob(); private val scope = CoroutineScope(Dispatchers.IO + job)
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var isAnalyzing = false
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate(); mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager; setupOverlayView()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel(); startForeground(NOTIFICATION_ID, createNotification())
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        try {
            val resultCode = intent!!.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_OK)
            val data = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
            if (data != null) { mp = mpm.getMediaProjection(resultCode, data); startScreenCapture() } else { stopSelf() }
        } catch (e: Exception) { Log.e(TAG, "Error onStartCommand", e); stopSelf() }
        return START_NOT_STICKY
    }

    @SuppressLint("InflateParams")
    private fun setupOverlayView() {
        try {
            highlightView = HighlightView(this)
            val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
            val params = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, layoutFlag, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
            wm.addView(highlightView, params)
        } catch (e: Exception) { Log.e(TAG, "Error setupOverlayView", e); stopSelf() }
    }

    private fun startScreenCapture() {
        try {
            ir = ImageReader.newInstance(width, height, PixelFormat.RGB_565, 2)
            vd = mp?.createVirtualDisplay("Capture", width, height, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, ir?.surface, null, null)
            scope.launch { while (isActive) { if (!isAnalyzing) analyzeLatestImage(); delay(ANALYSIS_INTERVAL_MS) } }
        } catch (e: Exception) { Log.e(TAG, "Error startScreenCapture", e); stopSelf() }
    }

    private fun analyzeLatestImage() {
        isAnalyzing = true
        val image = try { ir?.acquireLatestImage() } catch (e: Exception) { null } ?: run { isAnalyzing = false; return }
        val inputImage = InputImage.fromMediaImage(image, 0); image.close()
        recognizer.process(inputImage).addOnSuccessListener { visionText ->
            val numbers = mutableListOf<Pair<Int, Rect>>()
            visionText.textBlocks.forEach { b -> b.lines.forEach { l -> l.elements.forEach { e -> e.text.toIntOrNull()?.let { n -> e.boundingBox?.let { r -> numbers.add(n to r) } } } } }
            findCombinationsAndDraw(numbers); isAnalyzing = false
        }.addOnFailureListener { e -> Log.e(TAG, "OCR failed", e); isAnalyzing = false }
    }

    private fun findCombinationsAndDraw(numbers: List<Pair<Int, Rect>>) {
        val all = mutableListOf<List<Pair<Int, Rect>>>()
        fun find(start: Int, sum: Int, combo: MutableList<Pair<Int, Rect>>) {
            if (sum == 10) { all.add(ArrayList(combo)); return }
            if (sum > 10 || start >= numbers.size) return
            for (i in start until numbers.size) {
                combo.add(numbers[i]); find(i + 1, sum + numbers[i].first, combo); combo.removeAt(combo.size - 1)
            }
        }
        find(0, 0, mutableListOf()); highlightView?.setCombinations(all)
    }

    private fun createNotification(): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, NOTIFICATION_CHANNEL_ID).setContentTitle("사과게임 도우미").setContentText("화면을 분석하고 있습니다.").setSmallIcon(android.R.drawable.ic_menu_camera).setContentIntent(pi).build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val c = NotificationChannel(NOTIFICATION_CHANNEL_ID, "Service Channel", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(c)
        }
    }

    override fun onDestroy() {
        super.onDestroy(); job.cancel(); vd?.release(); mp?.stop(); ir?.close()
        if (highlightView?.isAttachedToWindow == true) wm.removeView(highlightView)
    }
}