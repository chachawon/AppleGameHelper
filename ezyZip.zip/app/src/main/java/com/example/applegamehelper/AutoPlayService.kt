package com.example.applegamehelper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.res.Resources
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*

class AutoPlayService : AccessibilityService() {
    companion object {
        private const val TAG = "AutoPlayService"; var instance: AutoPlayService? = null; var mp: MediaProjection? = null
        private const val ANALYSIS_INTERVAL_MS = 1000L; private const val DRAG_DURATION_MS = 250L
    }
    private var vd: VirtualDisplay? = null; private var ir: ImageReader? = null
    private val density by lazy { Resources.getSystem().displayMetrics.densityDpi }
    private val width by lazy { Resources.getSystem().displayMetrics.widthPixels }
    private val height by lazy { Resources.getSystem().displayMetrics.heightPixels }
    private val job = SupervisorJob(); private val scope = CoroutineScope(Dispatchers.IO + job)
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var isBusy = false
    override fun onServiceConnected() { super.onServiceConnected(); instance = this; startScreenAnalysis() }

    fun setupAndStartCapture() { Log.d(TAG, "Starting capture from MainActivity."); startScreenAnalysis() }

    private fun startScreenAnalysis() {
        if (mp == null) { Log.w(TAG, "MediaProjection is not set."); return }
        if (vd != null) { Log.d(TAG, "Analysis already running."); return }
        try {
            ir = ImageReader.newInstance(width, height, PixelFormat.RGB_565, 2)
            vd = mp?.createVirtualDisplay("AutoCapture", width, height, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, ir?.surface, null, null)
            scope.launch { while (isActive) { if (!isBusy) analyzeLatestImage(); delay(ANALYSIS_INTERVAL_MS) } }
        } catch (e: Exception) { Log.e(TAG, "Error starting screen analysis.", e) }
    }

    private fun analyzeLatestImage() {
        isBusy = true
        val image = try { ir?.acquireLatestImage() } catch (e: Exception) { null } ?: run { isBusy = false; return }
        val inputImage = InputImage.fromMediaImage(image, 0); image.close()
        recognizer.process(inputImage).addOnSuccessListener { visionText ->
            val numbers = mutableListOf<Pair<Int, Rect>>()
            visionText.textBlocks.forEach { b -> b.lines.forEach { l -> l.elements.forEach { e -> e.text.toIntOrNull()?.let { n -> e.boundingBox?.let { r -> numbers.add(n to r) } } } } }
            findAndPerformDrag(numbers)
        }.addOnFailureListener { Log.e(TAG, "OCR failed"); isBusy = false }
    }

    private fun findAndPerformDrag(numbers: List<Pair<Int, Rect>>) {
        fun find(start: Int, sum: Int, combo: MutableList<Pair<Int, Rect>>) {
            if (sum == 10) { performDrag(combo); throw StopSearchException() }
            if (sum > 10 || start >= numbers.size) return
            for (i in start until numbers.size) {
                combo.add(numbers[i]); find(i + 1, sum + numbers[i].first, combo); combo.removeAt(combo.size - 1)
            }
        }
        try { find(0, 0, mutableListOf()); isBusy = false } catch (e: StopSearchException) { Log.d(TAG, "Drag initiated.") }
    }

    private fun performDrag(combo: List<Pair<Int, Rect>>) {
        if (combo.size < 2) { isBusy = false; return }
        val path = Path().apply { moveTo(combo.first().second.exactCenterX(), combo.first().second.exactCenterY()); for (i in 1 until combo.size) { lineTo(combo[i].second.exactCenterX(), combo[i].second.exactCenterY()) } }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, DRAG_DURATION_MS)).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { scope.launch { delay(500); isBusy = false } }
            override fun onCancelled(g: GestureDescription?) { isBusy = false }
        }, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { stopAndCleanup(); return super.onUnbind(intent) }
    private fun stopAndCleanup() { job.cancel(); vd?.release(); vd = null; mp?.stop(); mp = null; ir?.close(); ir = null; instance = null }
    private class StopSearchException : RuntimeException()
}