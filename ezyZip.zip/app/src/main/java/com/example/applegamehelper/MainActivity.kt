package com.example.applegamehelper

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Button
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var mpm: MediaProjectionManager; private lateinit var tvOverlay: TextView
    private lateinit var tvAccess: TextView; private lateinit var rgMode: RadioGroup

    private val captureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            if (rgMode.checkedRadioButtonId == R.id.rb_helper_mode) {
                val intent = Intent(this, OverlayService::class.java).apply {
                    action = OverlayService.ACTION_START
                    putExtra(OverlayService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(OverlayService.EXTRA_DATA, result.data)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
                Toast.makeText(this, "도우미 모드를 시작합니다.", Toast.LENGTH_LONG).show()
            } else {
                AutoPlayService.mp = mpm.getMediaProjection(result.resultCode, result.data!!)
                AutoPlayService.instance?.setupAndStartCapture()
                Toast.makeText(this, "자동 봇 모드를 시작합니다.", Toast.LENGTH_LONG).show()
            }
            finish()
        } else { Toast.makeText(this, "화면 캡처가 거부되었습니다.", Toast.LENGTH_SHORT).show() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        tvOverlay = findViewById(R.id.tv_overlay_status); tvAccess = findViewById(R.id.tv_accessibility_status)
        rgMode = findViewById(R.id.rg_mode_selector)
        findViewById<Button>(R.id.btn_start).setOnClickListener { handleStart() }
        findViewById<Button>(R.id.btn_stop).setOnClickListener {
            stopService(Intent(this, OverlayService::class.java).apply { action = OverlayService.ACTION_STOP })
            if (isAccessibilityEnabled()) Toast.makeText(this, "봇을 멈추려면 설정 > 접근성에서 꺼주세요.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() { super.onResume(); updateStatus() }

    private fun handleStart() {
        if (rgMode.checkedRadioButtonId == R.id.rb_helper_mode) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "'다른 앱 위에 표시' 권한을 허용하세요.", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else { captureLauncher.launch(mpm.createScreenCaptureIntent()) }
        } else {
            if (!isAccessibilityEnabled()) {
                Toast.makeText(this, "'접근성' 설정에서 앱을 활성화하세요.", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else { captureLauncher.launch(mpm.createScreenCaptureIntent()) }
        }
    }

    private fun updateStatus() {
        tvOverlay.text = "다른 앱 위에 표시 권한: ${if (Settings.canDrawOverlays(this)) "ON" else "OFF"}"
        tvOverlay.setTextColor(if (Settings.canDrawOverlays(this)) Color.GREEN else Color.RED)
        tvAccess.text = "접근성 권한: ${if (isAccessibilityEnabled()) "ON" else "OFF"}"
        tvAccess.setTextColor(if (isAccessibilityEnabled()) Color.GREEN else Color.RED)
    }

    private fun isAccessibilityEnabled(): Boolean {
        val service = "$packageName/${AutoPlayService::class.java.canonicalName}"
        val setting = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        return setting?.let { TextUtils.SimpleStringSplitter(':').apply { setString(it) }.any { s -> s.equals(service, true) } } ?: false
    }
}